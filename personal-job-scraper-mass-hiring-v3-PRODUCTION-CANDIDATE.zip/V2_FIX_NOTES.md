# mass-hiring-v2 filter + first-party fix

- Full-time only: internships/co-ops excluded.
- Strict title seniority exclusions: Senior/Sr/Staff/Principal/Lead/Manager/Director and Level 3/4.
- US-only filtering now rejects explicit foreign locations even when they also say Remote.
- Systems Engineer is no longer a generic software match; hardware/power/avionics/IT/physical-security systems noise is excluded.
- Clearly stale (>120 day) postings from newly added sources are suppressed from bootstrap alerts.
- Mass-hiring/burst detection runs only after all filters and de-duplication.
- First-party source handling added for Google Careers, Apple Jobs, Amazon Jobs, plus generic official-portal parsing for Meta/Microsoft.
- source_health.csv records which sources actually work from GitHub Actions.
- The console prints explicit status for Google, Meta, Amazon, Apple, and Microsoft each run.

Do not merge to main until source health and two consecutive manual runs look correct.
