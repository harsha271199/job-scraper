# 📢 Job Listings for Harsha — July 24, 2026
> Updated every hour. Newest batch first.

### 🕐 Batch at 2026-07-24 23:51:31

📊 **3 new jobs this batch:**
- Anthropic: 1 job
- Handshake: 1 job
- Nvidia: 1 job

| 🏢 Company | 📍 Location | 💼 Role | 🔗 Link | 📅 Posted |
|---|---|---|---|---|
| **Handshake** | San Francisco, CA | Applied AI Engineer, Handshake AI Enterprise | [Apply](https://jobs.ashbyhq.com/handshake/b777e140-6ccd-44e6-9709-5a43c4b1ca7a) | 2026-05-19T12:41:22.147+00:00 |
| **Anthropic** | San Francisco, CA | New York City, NY | Research Scientist, Takeoff Intel | [Apply](https://job-boards.greenhouse.io/anthropic/jobs/5370669008) | 2026-07-24T19:31:13-04:00 |
| **Nvidia** | US, WA, Seattle | Research Scientist, Robotics Research -  PhD New College Grad 2026 | [Apply](https://nvidia.wd5.myworkdayjobs.com/en-US/NVIDIAExternalCareerSite/job/US-WA-Seattle/Research-Scientist--Robotics-Research----PhD-New-College-Grad-2026_JR2011473) | Posted Today |

---
# 📢 Job Listings for Harsha — July 24, 2026
> Updated every hour. Newest batch first.

### 🕐 Batch at 2026-07-24 22:49:09

📊 **4 new jobs this batch:**
- Guidehouse: 1 job
- Samsara: 1 job
- Woven by Toyota: 1 job
- Zoox: 1 job

| 🏢 Company | 📍 Location | 💼 Role | 🔗 Link | 📅 Posted |
|---|---|---|---|---|
| **Samsara** | Remote - SF Bay Area | Sr. Software Engineer II, AI Platform | [Apply](https://www.samsara.com/company/careers/roles/8050373?gh_jid=8050373) | 2026-07-24T18:28:46-04:00 |
| **Woven by Toyota** | Ann Arbor, MI | Software Engineer - Data Workflows | [Apply](https://jobs.lever.co/woven-by-toyota/ba39a024-c4c3-4966-a696-95db0e1dc445) | 2026-07-24 20:58 |
| **Zoox** | Foster City, CA | Software Engineer, Fleet Simulation (Core Data Science) | [Apply](https://jobs.lever.co/zoox/18b6dfa0-d581-4d29-ac79-5d6e666aa9c3) | 2026-07-24 22:20 |
| **Guidehouse** | US - VA, McLean | Software Developer (Java / ETL) | [Apply](https://guidehouse.wd1.myworkdayjobs.com/en-US/External/job/US---VA-McLean/Software-Developer--Java---ETL-_42464) | Posted Today |

---
# 📢 Job Listings for Harsha — July 24, 2026
> Updated every hour. Newest batch first.

### 🕐 Batch at 2026-07-24 21:51:51

📊 **6 new jobs this batch:**
- Northrop Grumman: 1 job
- OpenAI: 2 jobs
- SpaceX: 1 job
- Stripe: 2 jobs

| 🏢 Company | 📍 Location | 💼 Role | 🔗 Link | 📅 Posted |
|---|---|---|---|---|
| **OpenAI** | San Francisco | Data Scientist, GTM | [Apply](https://jobs.ashbyhq.com/openai/584fc51a-1107-457c-b499-a94fe5ef02b4) | 2026-07-24T21:39:48.970+00:00 |
| **OpenAI** | San Francisco | Data Engineer, CPU & Storage | [Apply](https://jobs.ashbyhq.com/openai/0c0fe7aa-24fb-4bad-aa30-3f68f1418e37) | 2026-07-24T20:44:16.847+00:00 |
| **SpaceX** | Hawthorne, CA | Production Engineer, Site Reliability (Application Software) | [Apply](https://boards.greenhouse.io/spacex/jobs/8649729002?gh_jid=8649729002) | 2026-07-24T16:11:09-04:00 |
| **Stripe** | Chicago, IL  | Backend Engineer, Credit Decisions  | [Apply](https://stripe.com/jobs/search?gh_jid=8084195) | 2026-07-24T16:10:18-04:00 |
| **Stripe** | South San Francisco, California | Software Engineer - Full Stack | [Apply](https://stripe.com/jobs/search?gh_jid=8084193) | 2026-07-24T16:10:08-04:00 |
| **Northrop Grumman** | United States-Alabama-Huntsville | Software Engineer - Level 4 | [Apply](https://ngc.wd1.myworkdayjobs.com/en-US/Northrop_Grumman_External_Site/job/United-States-Alabama-Huntsville/Software-Engineer---Level-4_R10242249) | Posted Today |

---
# 📢 Job Listings for Harsha — July 24, 2026
> Updated every hour. Newest batch first.

### 🕐 Batch at 2026-07-24 20:08:13

📊 **5 new jobs this batch:**
- Booz Allen Hamilton: 4 jobs
- Snowflake: 1 job

| 🏢 Company | 📍 Location | 💼 Role | 🔗 Link | 📅 Posted |
|---|---|---|---|---|
| **Snowflake** | US-CA-Menlo Park | Software Engineer- Postgres | [Apply](https://jobs.ashbyhq.com/snowflake/494fcbd0-1cf3-4248-b5cf-b35d982ced00) | 2026-07-24T19:59:32.556+00:00 |
| **Booz Allen Hamilton** | Fort Meade, MD | Data Scientist | [Apply](https://bah.wd1.myworkdayjobs.com/en-US/BAH_Jobs/job/Fort-Meade-MD/Data-Scientist_R0245296-1) | Posted Today |
| **Booz Allen Hamilton** | Springfield, VA | Business Analyst | [Apply](https://bah.wd1.myworkdayjobs.com/en-US/BAH_Jobs/job/Springfield-VA/Business-Analyst_R0233874) | Posted Today |
| **Booz Allen Hamilton** | Chantilly, VA | DevOps Engineer, Mid | [Apply](https://bah.wd1.myworkdayjobs.com/en-US/BAH_Jobs/job/Chantilly-VA/DevOps-Engineer--Mid_R0238594) | Posted Today |
| **Booz Allen Hamilton** | Washington, DC | Data Scientist | [Apply](https://bah.wd1.myworkdayjobs.com/en-US/BAH_Jobs/job/Washington-DC/Data-Scientist_R0245271-1) | Posted Today |

---
# 📢 Job Listings for Harsha — July 24, 2026
> Updated every hour. Newest batch first.

### 🕐 Batch at 2026-07-24 18:08:41

📊 **4 new jobs this batch:**
- Booz Allen Hamilton: 1 job
- General Motors: 1 job
- Pinterest: 1 job
- Verkada: 1 job

| 🏢 Company | 📍 Location | 💼 Role | 🔗 Link | 📅 Posted |
|---|---|---|---|---|
| **Pinterest** | Toronto, ON, CA | Software Engineer II, tvScientific | [Apply](https://www.pinterestcareers.com/jobs/?gh_jid=7782535) | 2026-07-24T13:07:53-04:00 |
| **Verkada** | San Mateo, CA United States | Backend Engineer - Connectivity | [Apply](https://job-boards.greenhouse.io/verkada/jobs/5194598007) | 2026-07-24T13:18:48-04:00 |
| **Booz Allen Hamilton** | Washington, DC | Data Scientist, Mid | [Apply](https://bah.wd1.myworkdayjobs.com/en-US/BAH_Jobs/job/Washington-DC/Data-Scientist--Mid_R0245282) | Posted Today |
| **General Motors** | Warren, Michigan, United States of America | Data Analyst | [Apply](https://generalmotors.wd5.myworkdayjobs.com/en-US/Careers_GM/job/Warren-Michigan-United-States-of-America/Data-Analyst_JR-202615362) | Posted Today |

---
# 📢 Job Listings for Harsha — July 24, 2026
> Updated every hour. Newest batch first.

### 🕐 Batch at 2026-07-24 14:31:00

📊 **7 new jobs this batch:**
- Boeing: 1 job
- Booz Allen Hamilton: 3 jobs
- Medtronic: 2 jobs
- Twilio: 1 job

| 🏢 Company | 📍 Location | 💼 Role | 🔗 Link | 📅 Posted |
|---|---|---|---|---|
| **Twilio** | Remote - US | Software Engineer (L2) | [Apply](https://job-boards.greenhouse.io/twilio/jobs/7946610) | 2026-07-24T10:02:19-04:00 |
| **Boeing** | USA - Richardson, TX | Software Engineer–Developer (Associate and Mid-Level) | [Apply](https://boeing.wd1.myworkdayjobs.com/en-US/external_careers/job/USA---Richardson-TX/Software-Engineer-Developer--Associate-and-Mid-Level-_JR2026512419-1) | Posted Today |
| **Booz Allen Hamilton** | Chantilly, VA | DevOps Engineer, Mid | [Apply](https://bah.wd1.myworkdayjobs.com/en-US/BAH_Jobs/job/Chantilly-VA/DevOps-Engineer--Mid_R0245245) | Posted Today |
| **Booz Allen Hamilton** | Chantilly, VA | DevOps Engineer, Mid | [Apply](https://bah.wd1.myworkdayjobs.com/en-US/BAH_Jobs/job/Chantilly-VA/DevOps-Engineer--Mid_R0245243) | Posted Today |
| **Booz Allen Hamilton** | Roseville, CA | Software Engineer | [Apply](https://bah.wd1.myworkdayjobs.com/en-US/BAH_Jobs/job/Roseville-CA/Software-Engineer_R0238409) | Posted Today |
| **Medtronic** | Lafayette, Colorado, United States of America | Prin Software Engineer | [Apply](https://medtronic.wd1.myworkdayjobs.com/en-US/MedtronicCareers/job/Lafayette-Colorado-United-States-of-America/Prin-Software-Engineer_R62027-1) | Posted Today |
| **Medtronic** | Lafayette, Colorado, United States of America | Software Engineer I (AI-Driven Data Solutions) - Lafayette, CO | [Apply](https://medtronic.wd1.myworkdayjobs.com/en-US/MedtronicCareers/job/Lafayette-Colorado-United-States-of-America/Software-Engineer-I--AI-Driven-Data-Solutions----Lafayette--CO_R72435-1) | Posted Today |

---
# 📢 Job Listings for Harsha — July 24, 2026
> Updated every hour. Newest batch first.

### 🕐 Batch at 2026-07-24 10:03:29

📊 **2 new jobs this batch:**
- Affirm: 2 jobs

| 🏢 Company | 📍 Location | 💼 Role | 🔗 Link | 📅 Posted |
|---|---|---|---|---|
| **Affirm** | Remote Spain | Software Engineer II, Backend (Collections) | [Apply](https://job-boards.greenhouse.io/affirm/jobs/7813157003) | 2026-07-24T05:37:02-04:00 |
| **Affirm** | Remote Poland | Software Engineer II, Backend (Collections) | [Apply](https://job-boards.greenhouse.io/affirm/jobs/7813159003) | 2026-07-24T05:37:03-04:00 |

---
# 📢 Job Listings for Harsha — July 24, 2026
> Updated every hour. Newest batch first.

### 🕐 Batch at 2026-07-24 01:18:03

📊 **2 new jobs this batch:**
- Nvidia: 1 job
- SpaceX: 1 job

| 🏢 Company | 📍 Location | 💼 Role | 🔗 Link | 📅 Posted |
|---|---|---|---|---|
| **SpaceX** | Memphis, TN | Full Stack Software Engineer (Application Software) | [Apply](https://boards.greenhouse.io/spacex/jobs/8648213002?gh_jid=8648213002) | 2026-07-23T21:00:59-04:00 |
| **Nvidia** | US, CA, Santa Clara | Software Engineer, Performance Lab and Tools | [Apply](https://nvidia.wd5.myworkdayjobs.com/en-US/NVIDIAExternalCareerSite/job/US-CA-Santa-Clara/Software-Engineer--Performance-Lab-and-Tools_JR2014711) | Posted Today |

---
