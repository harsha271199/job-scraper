# 📢 Job Listings for Harsha — August 10, 2026
> Updated every hour. Newest batch first.

### 🕐 Batch at 2026-08-10 23:22:58

📊 **1 new jobs this batch:**
- OpenAI: 1 job

| 🏢 Company | 📍 Location | 💼 Role | 🔗 Link | 📅 Posted |
|---|---|---|---|---|
| **OpenAI** | San Francisco | Applied AI Engineer, Enterprise | [Apply](https://jobs.ashbyhq.com/openai/01091aed-427d-4e10-8cdb-fb500cf55bb9) | 2026-07-08T23:07:51.379+00:00 |

---
# 📢 Job Listings for Harsha — August 10, 2026
> Updated every hour. Newest batch first.

### 🕐 Batch at 2026-08-10 22:23:49

📊 **5 new jobs this batch:**
- GE HealthCare: 1 job
- Hadrian: 1 job
- PayPal: 3 jobs

| 🏢 Company | 📍 Location | 💼 Role | 🔗 Link | 📅 Posted |
|---|---|---|---|---|
| **Hadrian** | Los Angeles, CA | Data Engineer | [Apply](https://jobs.ashbyhq.com/hadrian-automation/ece57d19-3718-41d9-8647-3448fcf94849) | 2026-08-10T22:19:55.105+00:00 |
| **GE HealthCare** | WA07-01-Bellevue-1100-112th Avenue NE | Sr AI Engineer | [Apply](https://gehc.wd5.myworkdayjobs.com/en-US/GEHC_ExternalSite/job/WA07-01-Bellevue-1100-112th-Avenue-NE/Sr-AI-Engineer_R4044339-1) | Posted Today |
| **PayPal** | San Jose, California, United States of America | Machine Learning Engineer | [Apply](https://paypal.wd1.myworkdayjobs.com/en-US/jobs/job/San-Jose-California-United-States-of-America/Machine-Learning-Engineer_R0137221) | Posted Today |
| **PayPal** | San Jose, California, United States of America | Sr Software Engineer | [Apply](https://paypal.wd1.myworkdayjobs.com/en-US/jobs/job/San-Jose-California-United-States-of-America/Sr-Software-Engineer_R0137222) | Posted Today |
| **PayPal** | San Jose, California, United States of America | Sr Software Engineer | [Apply](https://paypal.wd1.myworkdayjobs.com/en-US/jobs/job/San-Jose-California-United-States-of-America/Sr-Software-Engineer_R0137223) | Posted Today |

---
# 📢 Job Listings for Harsha — August 10, 2026
> Updated every hour. Newest batch first.

### 🕐 Batch at 2026-08-10 21:29:17

📊 **4 new jobs this batch:**
- Baseten: 1 job
- CVS Health: 1 job
- Intel: 1 job
- Mastercard: 1 job

| 🏢 Company | 📍 Location | 💼 Role | 🔗 Link | 📅 Posted |
|---|---|---|---|---|
| **Baseten** | San Francisco | Software Engineer - Observability | [Apply](https://jobs.ashbyhq.com/baseten/3e925ab1-2089-4a79-989e-50479b546eda) | 2026-08-10T20:38:17.932+00:00 |
| **CVS Health** | RI - Woonsocket | Software Engineer - SRE, Retail & Pharmacy | [Apply](https://cvshealth.wd1.myworkdayjobs.com/en-US/CVS_Health_Careers/job/RI---Woonsocket/Software-Engineer---SRE--Retail---Pharmacy_R0987009) | Posted Today |
| **Intel** | US, Oregon, Hillsboro | Mfg Systems Software Engineer | [Apply](https://intel.wd1.myworkdayjobs.com/en-US/External/job/US-Oregon-Hillsboro/Mfg-Systems-Software-Engineer_JR0286221) | Posted Today |
| **Mastercard** | O'Fallon, Missouri | Software Engineer II | [Apply](https://mastercard.wd1.myworkdayjobs.com/en-US/CorporateCareers/job/OFallon-Missouri/Software-Engineer-II_R-287461) | Posted Today |

---
# 📢 Job Listings for Harsha — August 10, 2026
> Updated every hour. Newest batch first.

### 🕐 Batch at 2026-08-10 20:28:28

📊 **3 new jobs this batch:**
- Booz Allen Hamilton: 1 job
- Esri: 1 job
- SpaceX: 1 job

| 🏢 Company | 📍 Location | 💼 Role | 🔗 Link | 📅 Posted |
|---|---|---|---|---|
| **Esri** | Redlands, CA | Data Engineer II - Street Data | [Apply](https://www.esri.com/careers/5208470007?gh_jid=5208470007) | 2026-08-10T15:47:58-04:00 |
| **SpaceX** | Hawthorne, CA | Business Analyst (Starlink Market Analysis) | [Apply](https://boards.greenhouse.io/spacex/jobs/8657082002?gh_jid=8657082002) | 2026-08-10T16:03:34-04:00 |
| **Booz Allen Hamilton** | Norfolk, VA | Palantir Data Engineer | [Apply](https://bah.wd1.myworkdayjobs.com/en-US/BAH_Jobs/job/Norfolk-VA/Palantir-Data-Engineer_R0244009-1) | Posted Today |

---
# 📢 Job Listings for Harsha — August 10, 2026
> Updated every hour. Newest batch first.

### 🕐 Batch at 2026-08-10 19:45:38

📊 **5 new jobs this batch:**
- Databricks: 1 job
- Esri: 1 job
- Figma: 1 job
- Hadrian: 1 job
- Notion: 1 job

| 🏢 Company | 📍 Location | 💼 Role | 🔗 Link | 📅 Posted |
|---|---|---|---|---|
| **Hadrian** | San Francisco Bay Area, CA | Robotics Software Engineer, Perception | [Apply](https://jobs.ashbyhq.com/hadrian-automation/81aa9da8-eaff-4644-ae5b-a0d105509a0a) | 2026-08-10T19:10:08.482+00:00 |
| **Notion** | San Francisco, California | Software Engineer, Collections Infra | [Apply](https://jobs.ashbyhq.com/notion/ca74504a-9b91-4ce3-b0df-97919b46e749) | 2026-08-10T19:31:59.593+00:00 |
| **Databricks** | United States | Specialist Solutions Architect - Data Engineering & Warehousing (Digital Native Business) | [Apply](https://databricks.com/company/careers/open-positions/job?gh_jid=8694074002) | 2026-08-10T14:44:16-04:00 |
| **Esri** | Redlands, CA | Data Engineer II - Street Data | [Apply](https://www.esri.com/careers/5089948007?gh_jid=5089948007) | 2026-03-26T15:08:05-04:00 |
| **Figma** | San Francisco, CA • New York, NY | Software Engineer Intern (Winter 2027) | [Apply](https://boards.greenhouse.io/figma/jobs/6131089004?gh_jid=6131089004) | 2026-08-10T15:03:06-04:00 |

---
# 📢 Job Listings for Harsha — August 10, 2026
> Updated every hour. Newest batch first.

### 🕐 Batch at 2026-08-10 18:38:54

📊 **5 new jobs this batch:**
- Citi: 1 job
- Databricks: 1 job
- Flir: 1 job
- Mastercard: 1 job
- Medtronic: 1 job

| 🏢 Company | 📍 Location | 💼 Role | 🔗 Link | 📅 Posted |
|---|---|---|---|---|
| **Databricks** | United States | Specialist Solutions Architect - Data Engineering & Warehousing (Financial Services) | [Apply](https://databricks.com/company/careers/open-positions/job?gh_jid=8692962002) | 2026-08-10T14:20:46-04:00 |
| **Citi** | Ciudad De Mexico Distrito Federal Mexico | Banamex Business Analyst - Crédito al Consumo | [Apply](https://citi.wd5.myworkdayjobs.com/en-US/2/job/Ciudad-De-Mexico-Distrito-Federal-Mexico/Banamex-Business-Analyst---Crdito-al-Consumo_26984148-1) | Posted Today |
| **Flir** | US - Huntsville, AL | Jr. Software Engineer | [Apply](https://flir.wd1.myworkdayjobs.com/en-US/flircareers/job/US---Huntsville-AL/Jr-Software-Engineer_REQ36188) | Posted Today |
| **Mastercard** | O'Fallon, Missouri | Software Engineer I | [Apply](https://mastercard.wd1.myworkdayjobs.com/en-US/CorporateCareers/job/OFallon-Missouri/Software-Engineer-I_R-280783) | Posted Today |
| **Medtronic** | Lafayette, Colorado, United States of America | Sr Software Engineer | [Apply](https://medtronic.wd1.myworkdayjobs.com/en-US/MedtronicCareers/job/Lafayette-Colorado-United-States-of-America/Sr-Software-Engineer_R74079-1) | Posted Today |

---
# 📢 Job Listings for Harsha — August 10, 2026
> Updated every hour. Newest batch first.

### 🕐 Batch at 2026-08-10 17:41:26

📊 **6 new jobs this batch:**
- Booz Allen Hamilton: 2 jobs
- Chime: 1 job
- Gusto: 1 job
- HP: 1 job
- Pfizer: 1 job

| 🏢 Company | 📍 Location | 💼 Role | 🔗 Link | 📅 Posted |
|---|---|---|---|---|
| **Chime** | San Francisco, CA, USA | Software Engineer, Communication Platform | [Apply](https://boards.greenhouse.io/chime/jobs/8681191002?gh_jid=8681191002) | 2026-08-10T13:13:42-04:00 |
| **Gusto** | Denver, CO;San Francisco, CA;New York, NY; | Software Engineer, ML Platform | [Apply](https://job-boards.greenhouse.io/gusto/jobs/8073232) | 2026-08-10T13:18:12-04:00 |
| **Booz Allen Hamilton** | Chantilly, VA | DevOps Engineer | [Apply](https://bah.wd1.myworkdayjobs.com/en-US/BAH_Jobs/job/Chantilly-VA/DevOps-Engineer_R0245049) | Posted Today |
| **Booz Allen Hamilton** | Arlington, VA | Data Scientist, Mid | [Apply](https://bah.wd1.myworkdayjobs.com/en-US/BAH_Jobs/job/Arlington-VA/Data-Scientist--Mid_R0246418) | Posted Today |
| **HP** | Spring, Texas, United States of America | Security Software Engineer (R&D) | [Apply](https://hp.wd5.myworkdayjobs.com/en-US/ExternalCareerSite/job/Spring-Texas-United-States-of-America/Security-Software-Engineer--R-D-_3166702) | Posted Today |
| **Pfizer** | United States - Massachusetts - Cambridge | Machine Learning Data Engineer (AIM2) | [Apply](https://pfizer.wd1.myworkdayjobs.com/en-US/PfizerCareers/job/United-States---Massachusetts---Cambridge/Machine-Learning-Data-Engineer--AIM2-_4961809-1) | Posted Today |

---
# 📢 Job Listings for Harsha — August 10, 2026
> Updated every hour. Newest batch first.

### 🕐 Batch at 2026-08-10 16:39:39

📊 **13 new jobs this batch:**
- Booz Allen Hamilton: 11 jobs
- Cox Enterprises: 1 job
- Guidehouse: 1 job

| 🏢 Company | 📍 Location | 💼 Role | 🔗 Link | 📅 Posted |
|---|---|---|---|---|
| **Booz Allen Hamilton** | Chantilly, VA | DevOps Engineer | [Apply](https://bah.wd1.myworkdayjobs.com/en-US/BAH_Jobs/job/Chantilly-VA/DevOps-Engineer_R0245044) | Posted Today |
| **Booz Allen Hamilton** | Chantilly, VA | Human Capital Data Analyst | [Apply](https://bah.wd1.myworkdayjobs.com/en-US/BAH_Jobs/job/Chantilly-VA/Human-Capital-Data-Analyst_R0246412) | Posted Today |
| **Booz Allen Hamilton** | Arlington, VA | Cloud Engineer | [Apply](https://bah.wd1.myworkdayjobs.com/en-US/BAH_Jobs/job/Arlington-VA/Cloud-Engineer_R0238945) | Posted Today |
| **Booz Allen Hamilton** | Chantilly, VA | DevOps Engineer | [Apply](https://bah.wd1.myworkdayjobs.com/en-US/BAH_Jobs/job/Chantilly-VA/DevOps-Engineer_R0245031) | Posted Today |
| **Booz Allen Hamilton** | Chantilly, VA | DevOps Engineer | [Apply](https://bah.wd1.myworkdayjobs.com/en-US/BAH_Jobs/job/Chantilly-VA/DevOps-Engineer_R0245017) | Posted Today |
| **Booz Allen Hamilton** | Chantilly, VA | DevOps Engineer | [Apply](https://bah.wd1.myworkdayjobs.com/en-US/BAH_Jobs/job/Chantilly-VA/DevOps-Engineer_R0245050) | Posted Today |
| **Booz Allen Hamilton** | Chantilly, VA | Front End Software Engineer | [Apply](https://bah.wd1.myworkdayjobs.com/en-US/BAH_Jobs/job/Chantilly-VA/Front-End-Software-Engineer_R0245760) | Posted Today |
| **Booz Allen Hamilton** | Chantilly, VA | Data Engineer | [Apply](https://bah.wd1.myworkdayjobs.com/en-US/BAH_Jobs/job/Chantilly-VA/Data-Engineer_R0245235) | Posted Today |
| **Booz Allen Hamilton** | Chantilly, VA | Front-End Software Engineer | [Apply](https://bah.wd1.myworkdayjobs.com/en-US/BAH_Jobs/job/Chantilly-VA/Front-End-Software-Engineer_R0245772) | Posted Today |
| **Booz Allen Hamilton** | Chantilly, VA | Front-End Software Engineer | [Apply](https://bah.wd1.myworkdayjobs.com/en-US/BAH_Jobs/job/Chantilly-VA/Front-End-Software-Engineer_R0245448) | Posted Today |
| **Booz Allen Hamilton** | Chantilly, VA | Data Engineer | [Apply](https://bah.wd1.myworkdayjobs.com/en-US/BAH_Jobs/job/Chantilly-VA/Data-Engineer_R0245362) | Posted Today |
| **Cox Enterprises** | Carmel IN | Entry Level Software Engineer Carmel, IN | [Apply](https://cox.wd1.myworkdayjobs.com/en-US/Cox_External_Career_Site_1/job/Carmel-IN/Entry-Level-Software-Engineer-Carmel--IN_R202680859) | Posted Today |
| **Guidehouse** | US - VA, Arlington | Data Analyst (Dashboard Developer) | [Apply](https://guidehouse.wd1.myworkdayjobs.com/en-US/External/job/US---VA-Arlington/Data-Analyst--Dashboard-Developer-_42823-1) | Posted Today |

---
# 📢 Job Listings for Harsha — August 10, 2026
> Updated every hour. Newest batch first.

### 🕐 Batch at 2026-08-10 15:46:34

📊 **10 new jobs this batch:**
- Best Egg: 1 job
- Booz Allen Hamilton: 7 jobs
- Northrop Grumman: 1 job
- Waymo: 1 job

| 🏢 Company | 📍 Location | 💼 Role | 🔗 Link | 📅 Posted |
|---|---|---|---|---|
| **Waymo** | Mountain View, CA, USA; San Francisco, CA, USA; Kirkland, WA, USA; New York, NY, USA | ML Engineer, Foundation Model Recipes | [Apply](https://careers.withwaymo.com/jobs?gh_jid=8109035) | 2026-08-10T10:40:16-04:00 |
| **Best Egg** | Wilmington, DE | Product Data Scientist | [Apply](https://jobs.lever.co/BestEgg/d765dee1-1d22-4cf9-9c83-766e7ad7e171) | 2026-08-10 14:55 |
| **Booz Allen Hamilton** | Chantilly, VA | Data Engineer | [Apply](https://bah.wd1.myworkdayjobs.com/en-US/BAH_Jobs/job/Chantilly-VA/Data-Engineer_R0245373) | Posted Today |
| **Booz Allen Hamilton** | Chantilly, VA | Full-Stack Software Engineer | [Apply](https://bah.wd1.myworkdayjobs.com/en-US/BAH_Jobs/job/Chantilly-VA/Full-Stack-Software-Engineer_R0245774) | Posted Today |
| **Booz Allen Hamilton** | Chantilly, VA | Data Engineer | [Apply](https://bah.wd1.myworkdayjobs.com/en-US/BAH_Jobs/job/Chantilly-VA/Data-Engineer_R0245506) | Posted Today |
| **Booz Allen Hamilton** | Chantilly, VA | Cloud Engineer | [Apply](https://bah.wd1.myworkdayjobs.com/en-US/BAH_Jobs/job/Chantilly-VA/Cloud-Engineer_R0245205) | Posted Today |
| **Booz Allen Hamilton** | Chantilly, VA | Cloud Engineer | [Apply](https://bah.wd1.myworkdayjobs.com/en-US/BAH_Jobs/job/Chantilly-VA/Cloud-Engineer_R0245212) | Posted Today |
| **Booz Allen Hamilton** | Chantilly, VA | AI/ML Engineer | [Apply](https://bah.wd1.myworkdayjobs.com/en-US/BAH_Jobs/job/Chantilly-VA/AI-ML-Engineer_R0245425) | Posted Today |
| **Booz Allen Hamilton** | Colorado Springs, CO | Data Engineer | [Apply](https://bah.wd1.myworkdayjobs.com/en-US/BAH_Jobs/job/Colorado-Springs-CO/Data-Engineer_R0246414) | Posted Today |
| **Northrop Grumman** | United States-Colorado-Aurora | Full Stack Software Developer Level 3 or 4 (AHT) | [Apply](https://ngc.wd1.myworkdayjobs.com/en-US/Northrop_Grumman_External_Site/job/United-States-Colorado-Aurora/Full-Stack-Software-Developer-Level-3-or-4--AHT-_R10244715) | Posted Today |

---
# 📢 Job Listings for Harsha — August 10, 2026
> Updated every hour. Newest batch first.

### 🕐 Batch at 2026-08-10 14:09:52

📊 **3 new jobs this batch:**
- General Motors: 1 job
- Guidehouse: 2 jobs

| 🏢 Company | 📍 Location | 💼 Role | 🔗 Link | 📅 Posted |
|---|---|---|---|---|
| **General Motors** | Milford, Michigan, United States of America | Software Engineer - Electrification Propulsion | [Apply](https://generalmotors.wd5.myworkdayjobs.com/en-US/Careers_GM/job/Milford-Michigan-United-States-of-America/Software-Engineer---Electrification-Propulsion_JR-202616585) | Posted Today |
| **Guidehouse** | US - DC, Washington | Data Analyst & IT Consultant - Real Estate Portfolio | [Apply](https://guidehouse.wd1.myworkdayjobs.com/en-US/External/job/US---DC-Washington/Data-Analyst---IT-Consultant---Real-Estate-Portfolio_42980-1) | Posted Today |
| **Guidehouse** | US - Remote (Any location) | AI Engineer | [Apply](https://guidehouse.wd1.myworkdayjobs.com/en-US/External/job/US---Remote-Any-location/AI-Engineer_42927) | Posted Today |

---
# 📢 Job Listings for Harsha — August 10, 2026
> Updated every hour. Newest batch first.

### 🕐 Batch at 2026-08-10 07:02:34

📊 **1 new jobs this batch:**
- Scopely: 1 job

| 🏢 Company | 📍 Location | 💼 Role | 🔗 Link | 📅 Posted |
|---|---|---|---|---|
| **Scopely** | IN - Bangalore, India | Associate Agentic AI Engineer | [Apply](https://job-boards.greenhouse.io/scopely/jobs/5216135008?gh_jid=5216135008) | 2026-05-14T06:16:22-04:00 |

---
# 📢 Job Listings for Harsha — August 10, 2026
> Updated every hour. Newest batch first.

### 🕐 Batch at 2026-08-10 03:03:36

📊 **1 new jobs this batch:**
- Guidehouse: 1 job

| 🏢 Company | 📍 Location | 💼 Role | 🔗 Link | 📅 Posted |
|---|---|---|---|---|
| **Guidehouse** | US - VA, McLean | Platform Engineer / DevSecOps Engineer | [Apply](https://guidehouse.wd1.myworkdayjobs.com/en-US/External/job/US---VA-McLean/Platform-Engineer---DevSecOps-Engineer_42911) | Posted Today |

---
