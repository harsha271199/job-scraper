# 📢 Job Listings for Harsha — July 28, 2026
> Updated every hour. Newest batch first.

### 🕐 Batch at 2026-07-28 23:46:52

📊 **2 new jobs this batch:**
- Alteryx: 1 job
- Mastercard: 1 job

| 🏢 Company | 📍 Location | 💼 Role | 🔗 Link | 📅 Posted |
|---|---|---|---|---|
| **Alteryx** | US - Remote | AI Platform Engineer | [Apply](https://alteryx.wd108.myworkdayjobs.com/en-US/AlteryxCareers/job/US---Remote/AI-Platform-Engineer_R12336) | Posted Today |
| **Mastercard** | O'Fallon, Missouri | Software Engineer II | [Apply](https://mastercard.wd1.myworkdayjobs.com/en-US/CorporateCareers/job/OFallon-Missouri/Software-Engineer-II_R-284379) | Posted Today |

---
# 📢 Job Listings for Harsha — July 28, 2026
> Updated every hour. Newest batch first.

### 🕐 Batch at 2026-07-28 22:47:23

📊 **5 new jobs this batch:**
- Airbnb: 1 job
- Benchling: 1 job
- Booz Allen Hamilton: 1 job
- Citi: 1 job
- Snowflake: 1 job

| 🏢 Company | 📍 Location | 💼 Role | 🔗 Link | 📅 Posted |
|---|---|---|---|---|
| **Benchling** | San Francisco, CA | Software Engineer, Agents | [Apply](https://jobs.ashbyhq.com/benchling/c66a06b7-5d9e-4b6c-b35b-12c86bb72a71) | 2026-07-28T22:10:10.705+00:00 |
| **Snowflake** | US-CA-Menlo Park | Software Engineer - Database Engineering | [Apply](https://jobs.ashbyhq.com/snowflake/db1375f0-ea5d-404a-b640-259f94dbc995) | 2026-07-28T22:20:47.028+00:00 |
| **Airbnb** | United States | Software Engineer, Biztech Client and Identity | [Apply](https://careers.airbnb.com/positions/8093038?gh_jid=8093038) | 2026-07-28T17:54:05-04:00 |
| **Booz Allen Hamilton** | MacDill AFB, FL | Data Analyst, Mid | [Apply](https://bah.wd1.myworkdayjobs.com/en-US/BAH_Jobs/job/MacDill-AFB-FL/Data-Analyst--Mid_R0245563-1) | Posted Today |
| **Citi** | Ciudad De Mexico Distrito Federal Mexico | Banamex Analista Business Intelligence CDMX | [Apply](https://citi.wd5.myworkdayjobs.com/en-US/2/job/Ciudad-De-Mexico-Distrito-Federal-Mexico/Banamex-Analista-Business-Intelligence-CDMX_26981198) | Posted Today |

---
# 📢 Job Listings for Harsha — July 28, 2026
> Updated every hour. Newest batch first.

### 🕐 Batch at 2026-07-28 21:53:12

📊 **3 new jobs this batch:**
- Adobe: 1 job
- Broadcom: 1 job
- Northrop Grumman: 1 job

| 🏢 Company | 📍 Location | 💼 Role | 🔗 Link | 📅 Posted |
|---|---|---|---|---|
| **Adobe** | San Francisco | Machine Learning Engineer | [Apply](https://adobe.wd5.myworkdayjobs.com/en-US/external_experienced/job/San-Francisco/Machine-Learning-Engineer_R170754-1) | Posted Today |
| **Broadcom** | USA-Pennsylvania-Breinigsville-9999 Hamilton Blvd | MES Software Engineer/Data Analyst | [Apply](https://broadcom.wd1.myworkdayjobs.com/en-US/External_Career/job/USA-Pennsylvania-Breinigsville-9999-Hamilton-Blvd/MES-Software-Engineer-Data-Analyst_R026173) | Posted Today |
| **Northrop Grumman** | United States-Utah-Roy | Sentinel Associate / Software Engineer  - 19232 | [Apply](https://ngc.wd1.myworkdayjobs.com/en-US/Northrop_Grumman_External_Site/job/United-States-Utah-Roy/Sentinel-Associate---Software-Engineer----19232_R10242757) | Posted Today |

---
# 📢 Job Listings for Harsha — July 28, 2026
> Updated every hour. Newest batch first.

### 🕐 Batch at 2026-07-28 20:55:01

📊 **5 new jobs this batch:**
- Citi: 1 job
- Guidehouse: 2 jobs
- PayPal: 1 job
- SpaceX: 1 job

| 🏢 Company | 📍 Location | 💼 Role | 🔗 Link | 📅 Posted |
|---|---|---|---|---|
| **SpaceX** | Hawthorne, CA | Business Analyst (Starlink Growth Demand Planning) | [Apply](https://boards.greenhouse.io/spacex/jobs/8650057002?gh_jid=8650057002) | 2026-07-28T16:00:44-04:00 |
| **Citi** | Ciudad De Mexico Distrito Federal Mexico | Banamex- RSK/ Credit Consumer Risk Business Intelligence | [Apply](https://citi.wd5.myworkdayjobs.com/en-US/2/job/Ciudad-De-Mexico-Distrito-Federal-Mexico/Banamex--RSK--Credit-Consumer-Risk-Business-Intelligence_26981730) | Posted Today |
| **Guidehouse** | US - Remote (Any location) | Databricks Data Engineer | [Apply](https://guidehouse.wd1.myworkdayjobs.com/en-US/External/job/US---Remote-Any-location/Databricks-Data-Engineer_42292-1) | Posted Today |
| **Guidehouse** | US - Remote (Any location) | Databricks Data Scientist | [Apply](https://guidehouse.wd1.myworkdayjobs.com/en-US/External/job/US---Remote-Any-location/Databricks-Data-Scientist_42293) | Posted Today |
| **PayPal** | Austin, Texas, United States of America | Sr Software Engineer - Cloud Infrastructure and Devops | [Apply](https://paypal.wd1.myworkdayjobs.com/en-US/jobs/job/Austin-Texas-United-States-of-America/Sr-Software-Engineer---Cloud-Infrastructure-and-Devops_R0136772-1) | Posted Today |

---
# 📢 Job Listings for Harsha — July 28, 2026
> Updated every hour. Newest batch first.

### 🕐 Batch at 2026-07-28 19:01:34

📊 **9 new jobs this batch:**
- Booz Allen Hamilton: 3 jobs
- Crusoe: 2 jobs
- Northrop Grumman: 3 jobs
- Ramp: 1 job

| 🏢 Company | 📍 Location | 💼 Role | 🔗 Link | 📅 Posted |
|---|---|---|---|---|
| **Crusoe** | San Francisco, CA - US | Software Engineer, Storage | [Apply](https://jobs.ashbyhq.com/crusoe/4f5d34ed-0c05-4eec-b8f8-14663e114b02) | 2026-07-28T17:16:20.211+00:00 |
| **Crusoe** | San Francisco, CA - US | Software Engineer II, Crusoe Container Registry | [Apply](https://jobs.ashbyhq.com/crusoe/a212b163-5f6b-42d6-9e93-5578ccb869df) | 2026-07-28T17:28:00.625+00:00 |
| **Ramp** | New York, NY (HQ) | Software Engineer, AI Solutions | [Apply](https://jobs.ashbyhq.com/ramp/b614563f-3ce6-4dca-b5ba-0e5a6c8bda27) | 2026-07-28T17:56:57.225+00:00 |
| **Booz Allen Hamilton** | Chantilly, VA | Business Analyst | [Apply](https://bah.wd1.myworkdayjobs.com/en-US/BAH_Jobs/job/Chantilly-VA/Business-Analyst_R0245517) | Posted Today |
| **Booz Allen Hamilton** | Beavercreek, OH | Realtime Data Analytics Engineer | [Apply](https://bah.wd1.myworkdayjobs.com/en-US/BAH_Jobs/job/Beavercreek-OH/Realtime-Data-Analytics-Engineer_R0245465) | Posted Today |
| **Booz Allen Hamilton** | Tampa, FL | Data Scientist | [Apply](https://bah.wd1.myworkdayjobs.com/en-US/BAH_Jobs/job/Tampa-FL/Data-Scientist_R0245472) | Posted Today |
| **Northrop Grumman** | United States-California-Northridge | Software Engineer Level 2 (AHT) | [Apply](https://ngc.wd1.myworkdayjobs.com/en-US/Northrop_Grumman_External_Site/job/United-States-California-Northridge/Software-Engineer-Level-2--AHT-_R10242698) | Posted Today |
| **Northrop Grumman** | United States-Ohio-Cincinnati | Cyber Software Engineer | [Apply](https://ngc.wd1.myworkdayjobs.com/en-US/Northrop_Grumman_External_Site/job/United-States-Ohio-Cincinnati/Cyber-Software-Engineer_R10242662) | Posted Today |
| **Northrop Grumman** | United States-California-San Diego | Software Engineer - User Experience Applications | [Apply](https://ngc.wd1.myworkdayjobs.com/en-US/Northrop_Grumman_External_Site/job/United-States-California-San-Diego/Software-Engineer---User-Experience-Applications_R10242412) | Posted Today |

---
# 📢 Job Listings for Harsha — July 28, 2026
> Updated every hour. Newest batch first.

### 🕐 Batch at 2026-07-28 17:15:05

📊 **9 new jobs this batch:**
- Booz Allen Hamilton: 4 jobs
- Citi: 1 job
- Esri: 1 job
- OpenAI: 1 job
- SpaceX: 1 job
- Target: 1 job

| 🏢 Company | 📍 Location | 💼 Role | 🔗 Link | 📅 Posted |
|---|---|---|---|---|
| **OpenAI** | San Francisco | Software Engineer, Enterprise Verticals | [Apply](https://jobs.ashbyhq.com/openai/3229b152-015f-49ad-9921-9c9de95570c8) | 2026-07-28T16:57:21.964+00:00 |
| **SpaceX** | Redmond, WA | Software Engineer, Power Optimization (Starlink)  | [Apply](https://boards.greenhouse.io/spacex/jobs/8647459002?gh_jid=8647459002) | 2026-07-28T11:58:05-04:00 |
| **Esri** | Redlands, CA | Spatial Data Engineer I | [Apply](https://www.esri.com/careers/5195914007?gh_jid=5195914007) | 2026-07-28T11:15:50-04:00 |
| **Booz Allen Hamilton** | Tampa, FL | Data Engineer, Mid | [Apply](https://bah.wd1.myworkdayjobs.com/en-US/BAH_Jobs/job/Tampa-FL/Data-Engineer--Mid_R0245461) | Posted Today |
| **Booz Allen Hamilton** | Aurora, CO | Software Engineer | [Apply](https://bah.wd1.myworkdayjobs.com/en-US/BAH_Jobs/job/Aurora-CO/Software-Engineer_R0245493) | Posted Today |
| **Booz Allen Hamilton** | Wharton, NJ | AI/ML Engineer, Junior | [Apply](https://bah.wd1.myworkdayjobs.com/en-US/BAH_Jobs/job/Wharton-NJ/AI-ML-Engineer--Junior_R0245456) | Posted Today |
| **Booz Allen Hamilton** | Chantilly, VA | Human Capital Data Analyst | [Apply](https://bah.wd1.myworkdayjobs.com/en-US/BAH_Jobs/job/Chantilly-VA/Human-Capital-Data-Analyst_R0245427) | Posted Today |
| **Citi** | Ciudad De Mexico Distrito Federal Mexico | Banamex-Machine Learning Engineering | [Apply](https://citi.wd5.myworkdayjobs.com/en-US/2/job/Ciudad-De-Mexico-Distrito-Federal-Mexico/Banamex-Machine-Learning-Engineering_26973810-1) | Posted Today |
| **Target** | 7000 Target Pkwy N,NCD-0375 Brooklyn Park,MN 55445 | Sr Applied Data Scientist - RecSys (applied ML, PyTorch, ML Ops) | [Apply](https://target.wd5.myworkdayjobs.com/en-US/targetcareers/job/7000-Target-Pkwy-NNCD-0375-Brooklyn-ParkMN-55445/Sr-Applied-Data-Scientist---Item-Recommendations--applied-ML--PyTorch--ML-Ops-_R0000441173) | Posted Today |

---
# 📢 Job Listings for Harsha — July 28, 2026
> Updated every hour. Newest batch first.

### 🕐 Batch at 2026-07-28 15:08:54

📊 **3 new jobs this batch:**
- Flir: 1 job
- Medtronic: 1 job
- Workday: 1 job

| 🏢 Company | 📍 Location | 💼 Role | 🔗 Link | 📅 Posted |
|---|---|---|---|---|
| **Flir** | US - Falls Church, VA - CS | Data Scientist | [Apply](https://flir.wd1.myworkdayjobs.com/en-US/flircareers/job/US---Falls-Church-VA---CS/Data-Scientist_REQ35960) | Posted Today |
| **Medtronic** | Fridley, Minnesota, United States of America | Full Stack Cloud Software Engineer II | [Apply](https://medtronic.wd1.myworkdayjobs.com/en-US/MedtronicCareers/job/Fridley-Minnesota-United-States-of-America/Full-Stack-Cloud-Software-Engineer-II_R71118-1) | Posted Today |
| **Workday** | USA.VA.Reston | Software Development Engineer, SRE (US Federal) | [Apply](https://workday.wd5.myworkdayjobs.com/en-US/Workday/job/USAVAReston/Software-Development-Engineer--SRE--US-Federal-_JR-0108467) | Posted Today |

---
# 📢 Job Listings for Harsha — July 28, 2026
> Updated every hour. Newest batch first.

### 🕐 Batch at 2026-07-28 12:28:27

📊 **1 new jobs this batch:**
- Northrop Grumman: 1 job

| 🏢 Company | 📍 Location | 💼 Role | 🔗 Link | 📅 Posted |
|---|---|---|---|---|
| **Northrop Grumman** | United States-Virginia-Dulles | Graphics Simulation Software Engineer | [Apply](https://ngc.wd1.myworkdayjobs.com/en-US/Northrop_Grumman_External_Site/job/United-States-Virginia-Dulles/Graphics-Simulation-Software-Engineer_R10242581) | Posted Today |

---
# 📢 Job Listings for Harsha — July 28, 2026
> Updated every hour. Newest batch first.

### 🕐 Batch at 2026-07-28 04:50:15

📊 **1 new jobs this batch:**
- Scopely: 1 job

| 🏢 Company | 📍 Location | 💼 Role | 🔗 Link | 📅 Posted |
|---|---|---|---|---|
| **Scopely** | IN - Bangalore, India | Software Engineer, Java | [Apply](https://job-boards.greenhouse.io/scopely/jobs/5368250008?gh_jid=5368250008) | 2026-07-27T21:48:38-04:00 |

---
# 📢 Job Listings for Harsha — July 28, 2026
> Updated every hour. Newest batch first.

### 🕐 Batch at 2026-07-28 01:13:41

📊 **1 new jobs this batch:**
- Gusto: 1 job

| 🏢 Company | 📍 Location | 💼 Role | 🔗 Link | 📅 Posted |
|---|---|---|---|---|
| **Gusto** | San Francisco, CA | Software Engineer, People Technology | [Apply](https://job-boards.greenhouse.io/gusto/jobs/7947424) | 2026-06-09T18:51:05-04:00 |

---
