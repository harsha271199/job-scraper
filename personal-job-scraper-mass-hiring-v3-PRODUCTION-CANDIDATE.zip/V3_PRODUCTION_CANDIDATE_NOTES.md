# mass-hiring-v2 production-candidate notes

This branch keeps the original hourly behavior and existing company universe, then adds stricter quality controls and supplemental discovery.

## Quality fixes
- US-only location checks.
- Full-time only: internships/co-ops rejected.
- Senior/Staff/Principal/Lead/Manager/Director and Level 3/4 titles rejected.
- Explicit 4+ year minimum requirements rejected when descriptions are available.
- Workday candidate job descriptions are fetched before acceptance so experience requirements can be checked.
- Hardware/power/avionics/HVAC and other unrelated systems-engineering titles are rejected.
- Clearance-required jobs are rejected.
- Very stale explicit posting dates (>120 days) are not newly alerted.

## Discovery
- SpeedyApply 2027 AI New Grad USA is checked as a supplemental discovery feed.
- SpeedyApply 2027 SWE New Grad USA is checked as a supplemental discovery feed.
- Discovery jobs still pass the same US/title/seniority filters and use the direct employer posting URL when available.
- Discovery is supplemental; direct company/ATS sources remain primary.

## Mass hiring
- Cohort/new-grad program titles are detected.
- A generic hiring burst now requires at least 5 newly-seen jobs with evidence they were posted within ~14 days.
- This avoids calling an old backlog from a newly-added company a mass-hiring event.

## Source health
- source_health.csv reports every direct source plus discovery feeds.
- Google, Meta, Amazon, Apple, and Microsoft are printed explicitly in the workflow log.
- A first-party portal is not called working unless its GitHub Actions request actually succeeds and produces parseable records.
